from streamingdataframes import exceptions

__all__ = ("InvalidApplyResultType",)


class InvalidApplyResultType(exceptions.QuixException):
    ...
